// Simple Toaster placeholder for shadcn/ui
import * as React from "react";

export function Toaster() {
  // This is a placeholder. For real toast notifications, use a library like sonner or react-hot-toast.
  return null;
}
